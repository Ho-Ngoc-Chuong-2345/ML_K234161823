import pandas as pd

dataframe = pd.read_json("../datasets/SalesTransactions/SalesTransactions.json")

print(dataframe)